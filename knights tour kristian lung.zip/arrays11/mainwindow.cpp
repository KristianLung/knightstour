#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <array>
#include <QVector>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
bool MainWindow::isSafe(int x, int y) {
    return (x >= 0 && y >= 0 && x < N && y < N && ui->tableWidget->item(x, y) == nullptr);
}

bool MainWindow::solveKnightTour(int x, int y, int moveCount) {
    if (moveCount == N * N) {
        return true;
}
    //qDebug()<<"moveCount: "<< moveCount;

    // Code that checks all possible moves from the current square
    for (int i = 0; i < 8; i++) {
        int nextX = x + moveX[i];
        int nextY = y + moveY[i];

        // Code that Checks if the next box has been visited
        if (isSafe(nextX, nextY)) {
            QTableWidgetItem *item = new QTableWidgetItem(QString::number(moveCount + 1));
            ui->tableWidget->setItem(nextX, nextY, item);

            // Recursive call to explore the next move
            if (solveKnightTour(nextX, nextY, moveCount + 1)) {
                return true; // If a solution is found, return true
            }

            // If no solution is found, backtrack and reset the cell
            ui->tableWidget->setItem(nextX, nextY, nullptr);
        }
    }

    return false; // If no move is possible, return false
}
void MainWindow::startKnightTour() {
    ui->tableWidget->clear();
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> distribution(0, 7);

    // Sets the initial position of the knight
    int startX = distribution(gen);
    int startY = distribution(gen);

    QTableWidgetItem *item = new QTableWidgetItem("1");
    ui->tableWidget->setItem(startX, startY, item);

    // Start the Knight's Tour from the initial position
    if (solveKnightTour(startX, startY, 1)) {
        QMessageBox::information(this, "Knight's Tour", "Tour has been completed!");
    } else {
        QMessageBox::information(this, "Knight's Tour", "Unable to complete tour!");
    }
}

void MainWindow::on_pushButton_2_clicked()
{
startKnightTour();
}


void MainWindow::on_pushButton_clicked()
{
QMessageBox msgBox;
msgBox.setWindowTitle("Kristian Lung Lotama Info");
msgBox.setTextFormat(Qt::RichText);
QString Text1 = tr("<strong>Extra Info</strong> \n" );
QString Text3 = tr("<br />I accepted Dr.Rusman's Challenge, and created the knight's tour with a random starting position \n");
QString Text4 = tr("<br />Be aware that this program is core heavy, it is recommended to use multiple cores to run the program\n");
QString Text6 = tr("<br />This program will be uploaded to github\n");
msgBox.setText(Text1 + Text3 + Text4 + Text6);
msgBox.exec();
}

